#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>

int run(char, int);

//all informations for each child
struct child
{
  pid_t pid;
  char name;
};

int main(int argc,char* argv[])
{
  int i = 0;
  int j = 0;
  char alphabet = 'A';				//for naming the childs
  pid_t parentPid = 0;		
  pid_t childPid = 0;
  
  int givenSpeed = atoi(argv[2]);			//max Speed is given in m/sec
  if(givenSpeed > 20)				//max possible speed is 20 m/sec
  { 
    givenSpeed = 20;
  }
  else if( givenSpeed < 1)			//min possible speed is 1 m/sec		
  {
    givenSpeed = 1;
  }
  
  int nrOfChilds = atoi(argv[1]);		//how manx childs 
  int childsToWait = nrOfChilds;
  
  if(nrOfChilds > 10)				//max 10 childs
  { 
    nrOfChilds = 10;
  } 
  else if (nrOfChilds < 1)			//min 1 child
  {
    nrOfChilds = 1;
  }
  
  struct child allChilds[nrOfChilds];		//all childs 
  //printf("%d processes\n", nrOfChilds);
   
   
   
  for (i = 0; i<nrOfChilds; i++)	
  {
    allChilds[i].pid = fork();			//create n childs
    allChilds[i].name = alphabet;		//naming the child
    
    //child code
    if(allChilds[i].pid == 0 )			//child have to do other as parent
    {
      run(allChilds[i].name, givenSpeed);
      break;
    }
    //parent code
    else if(allChilds[i].pid != 0)
    {
   
    alphabet++;					//increment the name
    parentPid = getpid();
    printf("%c created\n",allChilds[i].name);
    }
  }//end for
  
  //parent code
  if(getpid() == parentPid)
  {    
    //wait for all childs
    
    //sammle der reihe nach in struct auf, damit entfällt sortieren
    
      j = 0;
      while ( j < childsToWait)
      {
	childPid = waitpid(-1, NULL, 0);
	j++;
	printf("waited for child %d\n", childPid);
      }
      printf("waited for all childs\n");
    }  
    
    //printf("%10d %15d %10ld %14d\n", blocksize, nrOfReads, time, checksum);
    //print table header
    printf("Platz \t Renner \t Zeit(sek)");
    
    
  return 0;
}

int run(char myName, int maxSpeed)
{
  int myWay = 0;	//run distance 
  int distance = 80;	//complete distance
  char outDistance[80] = "-";	//string for output
  char step[2] = "-";	// array of 2 because /0
  
  int uSec = 0;		//time to sleep
  int actSpeed = 0;	//speed in this loop
  
  //set beginning number of rand with an addition of actual time and the own pid
  srand ( ( time(NULL) + getpid() ) );
  
  while ( myWay < distance)
  {
    actSpeed = ( rand() % maxSpeed + 1);	//speed in this loop, between 1 and maxSpeed
    // calculate time to sleep
    uSec = ( 1000000 * 10 /actSpeed);
    
    myWay++;				//did one step
    usleep(uSec);		
    printf("%c %s\n", myName, outDistance);
    strcat(outDistance, step);
  }
  
  return 0;
}