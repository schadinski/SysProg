
//Katharina Schwab
//System Programmierung Labor 2


ssize_t read_buffered (int fd, void *buf, size_t nbytes);
