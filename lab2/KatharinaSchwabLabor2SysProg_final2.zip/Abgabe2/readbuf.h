//Katharina Schwab
//System Programmierung Labor 2


int read_buffered (int fd, void *buf, int nbytes);
